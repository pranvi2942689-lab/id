Component({
  properties:{ 
    title: { type: String, value: '' },
    backTo: { type: String, value: '\/pages\/home\/home' }
  },
  data:{
    statusBarHeight: 20,
    navHeight: 64
  },
  lifetimes:{
    attached(){
      try{
        const sys = wx.getSystemInfoSync();
        const rect = wx.getMenuButtonBoundingClientRect ? wx.getMenuButtonBoundingClientRect() : null;
        const statusBarHeight = sys.statusBarHeight || 20;
        let navHeight = statusBarHeight + 44;
        if(rect && rect.bottom){
          const gap = rect.top - statusBarHeight;
          const barHeight = gap*2 + rect.height;
          navHeight = statusBarHeight + barHeight;
        }
        this.setData({ statusBarHeight, navHeight });
      }catch(e){}
    }
  },
  methods:{
    goBack(){
      try{
        const pages = getCurrentPages();
        if(pages && pages.length > 1){ wx.navigateBack({ delta: 1 }); return; }
      }catch(e){}
      const to = (this && this.data && this.data.backTo) ? this.data.backTo : '/pages/home/home';
      wx.switchTab({ url: to, fail: () => wx.reLaunch({ url: to }) });
    },
    onBack(){ this.goBack(); }
  }
})