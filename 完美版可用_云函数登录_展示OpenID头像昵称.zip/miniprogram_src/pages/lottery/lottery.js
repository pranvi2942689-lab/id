const app = getApp();

Page({
  data:{
    tier:'3600',
    title:'抽奖',
    prizes:[],      // 根据 tier 注入（3 或 6 个）
    spinning:false,
    currentAngle:0  // 指针相对“正上方”的旋转角度（弧度）
  },
  onLoad(options){
    const tier = (options && options.tier) || '3600';
    let prizes = [];
    if(tier === '1200'){
      prizes = [
        {name:'《被讨厌的勇气》'},
        {name:'《不完美，才美》'},
        {name:'《情绪自救：告别内耗》'}
      ];
    }else if(tier === '2400'){
      prizes = [
        {name:'香氛护手霜三支礼盒'},
        {name:'便携LED化妆镜'},
        {name:'真丝枕套（单只）'},
        {name:'香薰蜡烛双件套'},
        {name:'350ml 保温随行杯'},
        {name:'丝绒发带礼盒'}
      ];
    }else{
      prizes = [
        {name:'真丝睡眠眼罩+发圈礼盒'},
        {name:'香薰机+精油礼盒（卧室款）'},
        {name:'便携冲牙器（旅行套装）'},
        {name:'mini 筋膜按摩器'},
        {name:'轻奢保温杯（保温保冷）'},
        {name:'瑜伽放松泡沫轴套装'}
      ];
    }
    const title = tier==='1200' ? '抽书（3选1）' : (tier==='2400' ? '盲盒礼物（6选1，100–200）' : '盲盒礼物（6选1，200–300）');

    // 固定 560rpx 的圆盘尺寸
    const sys = wx.getSystemInfoSync();
    const pxPerRpx = sys.windowWidth / 750;       // 1rpx = pxPerRpx px
    const sizeRpx = 560;                          // 恢复为 560rpx
    const wheelStyle = `width:${sizeRpx}rpx;height:${sizeRpx}rpx`;
    const canvasSize = sizeRpx * pxPerRpx;
    const center = canvasSize / 2;
    const radius = center - 12 * pxPerRpx;

    // 为不同份数准备不重复的颜色
    // 渐变色（每份不同，且不同于开始按钮 #f472b6->#a78bfa）
    const gradients6 = [
      ['#fb923c','#f97316'],
      ['#34d399','#10b981'],
      ['#60a5fa','#3b82f6'],
      ['#22d3ee','#06b6d4'],
      ['#f87171','#ef4444'],
      ['#a3e635','#84cc16']
    ];
    const gradients3 = [
      ['#fb923c','#f97316'],
      ['#60a5fa','#3b82f6'],
      ['#34d399','#10b981']
    ];
    const gradients = prizes.length===3 ? gradients3 : gradients6;

    this.setData({ tier, prizes, title, wheelStyle, _px:pxPerRpx, _center:center, _radius:radius, _gradients:gradients });
    this.drawWheel(this.data.currentAngle);
  },
  // 画轮盘（静止的圆盘 + 旋转的指针）
  drawWheel(pointerAngle=0){
    const ctx = wx.createCanvasContext('wheelCanvas', this);
    const center = this.data._center || (wx.getSystemInfoSync().windowWidth/750*560/2);
    const radius = this.data._radius || (center - 10);
    const prizes = this.data.prizes;
    const slice = 2*Math.PI / prizes.length;

    ctx.save();
    ctx.translate(center, center);

    // 1) 扇区（静止圆盘：每份使用不一样的线性渐变）
    const grads = this.data._gradients || [];
    for(let i=0;i<prizes.length;i++){
      ctx.save();
      ctx.beginPath();
      ctx.moveTo(0,0);
      ctx.arc(0,0,radius,i*slice,(i+1)*slice);
      ctx.closePath();

      // 为该扇区创建线性渐变（沿扇区径向方向）
      const g = ctx.createLinearGradient(0, 0, radius, 0);
      const c = grads[i % grads.length] || ['#e5e7eb','#cbd5e1'];
      g.addColorStop(0, c[0]);
      g.addColorStop(1, c[1]);
      ctx.setFillStyle(g);
      ctx.fill();
      ctx.restore();
    }

    // 2) 文本（限制在圆内 + 自适应字号不越界）（限制在圆内 + 自适应字号不越界）
    ctx.save();
    ctx.beginPath();
    ctx.arc(0,0,radius-4,0,2*Math.PI);
    ctx.clip();
    for(let i=0;i<prizes.length;i++){
      const name = prizes[i].name;
      const theta = i*slice + slice/2;
      const textR = radius * 0.70;
      let x = textR * Math.cos(theta);
      let y = textR * Math.sin(theta);
      if (Math.cos(theta) < 0.15 && Math.sin(theta) < -0.95) { y += 12; }

      // 可用宽度：同半径的弦长 0.85
      const avail = 2 * textR * Math.sin(slice/2) * 0.85;
      let fs = 16;
      ctx.setFontSize(fs);
      let w = ctx.measureText ? (ctx.measureText(name).width||0) : 0;
      while(w > avail && fs > 10){
        fs--; ctx.setFontSize(fs);
        w = ctx.measureText ? (ctx.measureText(name).width||0) : 0;
      }
      ctx.setFillStyle('#374151');
      ctx.setTextAlign('center');
      if (ctx.setTextBaseline) ctx.setTextBaseline('middle');
      ctx.fillText(name, x, y);
    }
    ctx.restore();

    // 3) 外圈
    ctx.beginPath();
    ctx.arc(0,0,radius,0,2*Math.PI);
    ctx.setStrokeStyle('#e5e7eb');
    ctx.setLineWidth(2);
    ctx.stroke();

    // 4) 旋转指针
    ctx.save();
    ctx.rotate(pointerAngle);
    ctx.beginPath();
    ctx.moveTo(0,-radius-6);
    ctx.lineTo(-10,-radius+28);
    ctx.lineTo(10,-radius+28);
    ctx.closePath();
    ctx.setFillStyle('#ef4444');
    ctx.fill();
    ctx.beginPath();
    ctx.arc(0,0,10,0,2*Math.PI);
    ctx.setFillStyle('#ef4444');
    ctx.fill();
    ctx.restore();

    ctx.restore();
    ctx.draw();
  },
  startSpin(){
    if(this.data.spinning) return;
    this.setData({spinning:true});

    const prizes = this.data.prizes;
    const targetIndex = Math.floor(Math.random()*prizes.length);
    const slice = 2*Math.PI / prizes.length;

    // 目标是让“指针”旋转到目标扇区的中心角度
    const sectorAngle = targetIndex*slice + slice/2;  // 从 +X 轴开始计
    // 基准指针默认指向“正上方”(-90deg)，要旋转到 sectorAngle：
    // -90° + rotation = sectorAngle => rotation = sectorAngle + 90°
    const finalAngle = sectorAngle + Math.PI/2;

    // 额外多转 6 圈，做动画
    const extra = 2*Math.PI*6;
    const start = this.data.currentAngle % (2*Math.PI);
    const totalRotate = extra + (finalAngle - start);

    const duration = 5000; // 5s ease-out
    const startTime = Date.now();
    const animate = () => {
      const now = Date.now();
      let t = (now - startTime) / duration;
      if(t > 1) t = 1;
      const ease = 1 - Math.pow(1 - t, 3);
      const angle = start + totalRotate * ease;
      this.setData({ currentAngle: angle });
      this.drawWheel(angle);
      if(t < 1){
        this._timer = setTimeout(animate, 16);
      }else{
        const prize = prizes[targetIndex];
        setTimeout(()=>{
          wx.showModal({
            title:'恭喜',
            content:`恭喜您抽中了 ${prize.name}`,
            showCancel:false,
            success:()=>{
              if(this.data.tier==='1200') app.globalData.lotteryDrawn1200 = true;
              else if(this.data.tier==='2400') app.globalData.lotteryDrawn2400 = true;
              else app.globalData.lotteryDrawn3600 = true;
              ((getApp&&getApp().safeNavigateBack)?getApp().safeNavigateBack(1, '/pages/home/home'):(function(){try{const _p=getCurrentPages(); if(_p && _p.length>1){((getApp&&getApp().safeNavigateBack)?getApp().safeNavigateBack(1, '/pages/home/home'):(function(){try{const _p=getCurrentPages(); if(_p && _p.length>1){wx.navigateBack({delta:1});} else {wx.switchTab({url:'/pages/home/home', fail:()=>wx.reLaunch({url:'/pages/home/home'})});}}catch(e){wx.switchTab({url:'/pages/home/home', fail:()=>wx.reLaunch({url:'/pages/home/home'})});}})());} else {wx.switchTab({url:'/pages/home/home', fail:()=>wx.reLaunch({url:'/pages/home/home'})});}}catch(e){wx.switchTab({url:'/pages/home/home', fail:()=>wx.reLaunch({url:'/pages/home/home'})});}})());
            }
          });
          this.setData({spinning:false});
        }, 1000);
      }
    };
    animate();
  },
  onUnload(){
    if(this._timer) clearTimeout(this._timer);
  }
});
