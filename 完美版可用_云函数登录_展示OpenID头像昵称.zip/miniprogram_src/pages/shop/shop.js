Page({
  data:{
    products:{
      salon:{ id:'salon', title:'线下沙龙', price:299, date:'2025-08-25', online:false },
      bookclub:{ id:'bookclub', title:'读书会（线上）', price:99, date:'2025-09-04', online:true }
    }
  },
  goPay(e){
    const id = e.currentTarget.dataset.id
    const p = this.data.products[id]
    wx.navigateTo({
      url: `/pages/shop_pay/shop_pay?id=${p.id}&title=${encodeURIComponent(p.title)}&price=${p.price}&date=${p.date}&online=${p.online?1:0}`
    })
  },
  goOrders(){ wx.navigateTo({ url:'/pages/shop_orders/shop_orders' }) }
})
