const app=getApp();
Page({
  data:{amount:'0'},
  onLoad(q){ this.setData({amount: q.amt || '0'}); },
  payNow(){
    if(app.globalData.payPurpose==='reservation'){
      const c = app.globalData.currentConsultant;
      const b = app.globalData.booking;
      app.globalData.orders.push({
        id: (Date.now()*1000 + Math.floor(Math.random()*1000)),
        consultant: c,
        price: c.price,
        date: b.date,
        slot: b.slot,
        method: b.method,
        paid: true,
        commented: false,
        rated: 0,
        tipped: false,
        tipAmount: 0,
        messages: [],
        awaitingReply: false
      });
      wx.showModal({title:'预约结果', content:'支付成功', showCancel:false, success:()=>{
        app.globalData.reOrderDiscount=null;
        app.globalData.payPurpose='reservation';
        wx.switchTab({url:'/pages/orders/orders'});
      }});
    }else{
      wx.navigateTo({url:'/pages/paypwd/paypwd?amt='+this.data.amount});
    }
  }
});
