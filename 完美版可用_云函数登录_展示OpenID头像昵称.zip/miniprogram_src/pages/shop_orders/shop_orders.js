const STORE_KEY = 'SHOP_ORDERS_V1'
Page({
  data:{ orders:[] },
  onShow(){
    const list = wx.getStorageSync(STORE_KEY) || []
    this.setData({ orders: list })
  }
})
