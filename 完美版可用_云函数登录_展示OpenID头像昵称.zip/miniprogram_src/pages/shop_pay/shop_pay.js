const STORE_KEY = 'SHOP_ORDERS_V1'

Page({
  data:{ id:'', title:'', price:0, date:'', online:false },
  onLoad(opt){
    this.setData({
      id: opt.id || '',
      title: decodeURIComponent(opt.title||''),
      price: Number(opt.price||0),
      date: opt.date || '',
      online: opt.online === '1'
    })
  },
  pay(){
    const order = {
      orderId: 'O' + Date.now(),
      productId: this.data.id,
      title: this.data.title,
      price: this.data.price,
      date: this.data.date,
      online: this.data.online,
      status: '已支付',
      paidAt: new Date().toISOString().replace('T',' ').slice(0,19)
    }
    const list = wx.getStorageSync(STORE_KEY) || []
    list.unshift(order)
    wx.setStorageSync(STORE_KEY, list)

    wx.showToast({ title:'支付成功（模拟）', icon:'success' })
    setTimeout(()=> wx.redirectTo({ url:'/pages/shop_orders/shop_orders' }), 400)
  }
})
