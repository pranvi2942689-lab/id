const app = getApp();
const cloud = require('../../utils/cloud.js');

Page({
  data: { userInfo: null, loading: false },
  onShow(){
    // 初次进入尝试从缓存恢复
    const cachedUser = app.globalData.userInfo || wx.getStorageSync('USERINFO') || null;
    if (cachedUser) app.globalData.userInfo = cachedUser;
    this.setData({ userInfo: app.globalData.userInfo || null });
  },
  async doLogin(){
    if (this.data.loading) return;
    this.setData({ loading: true });
    try {
      // 调用云函数获取 openid
      const r = await cloud.call('login', {}, {}, {showLoading:true});
      const openid = r && r.result && r.result.openid;
      if (!openid) throw new Error('未获取到OPENID');
      const user = { ...(app.globalData.userInfo || {}), openid };
      app.globalData.userInfo = user;
      wx.setStorageSync('USERINFO', user);
      this.setData({ userInfo: user });
      wx.showToast({ title: '登录成功', icon: 'success' });
    } catch(e){
      console.error('login失败', e);
      wx.showModal({ title:'登录失败', content:e.errMsg || e.message || '未知错误', showCancel:false });
    } finally {
      this.setData({ loading:false });
    }
  },
  // 单独拉取头像昵称（用户可能首次拒绝授权）
  getProfile(){
    wx.getUserProfile({
      desc:'用于完善资料',
      success: (res) => {
        const user = { ...(this.data.userInfo || {}), ...res.userInfo };
        app.globalData.userInfo = user;
        wx.setStorageSync('USERINFO', user);
        this.setData({ userInfo: user });
        wx.showToast({ title:'已获取资料', icon:'success' });
      },
      fail: () => wx.showToast({ title:'未授权头像昵称', icon:'none' })
    });
  },
  logout(){
    wx.removeStorageSync('USERINFO');
    wx.removeStorageSync('OPENID');
    app.globalData.userInfo = null;
    this.setData({ userInfo: null });
    wx.showToast({ title:'已退出', icon:'none' });
  }
});