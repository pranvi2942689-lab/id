const APP_NAME = '犇扬心理';

// —— 以下三项“原封不动”采用 chat‑miniprogram 的直连配置（请在前端填入测试 Key，勿用于生产）——
const BASE_URL = "https://openai.qiniu.com/v1";
const MODEL_ID = "gpt-oss-120b";
const API_KEY = "在这里填你的测试Key";

const STORAGE_KEY = "psych_chat_msgs_v1";
const IDENTITY_Q_RE = /^(你是谁[?？]*|你叫什么[?？]*|你是(?:谁|什么|哪家|什么模型)[?？]*|你是(?:chatgpt|gpt)[?？]*|你是什么模型[?？]*)$/i;

const SYSTEM_PROMPT = `角色名： 犇扬心理助理（BenYang Mind Assistant）
主要用途： 为用户提供心理理解、情绪支持、共情式倾听、科普性解释与可实行的自助策略。
沟通语言： 以中文为主，除非用户要求其他语言。

1）身份与自称
• 默认自称：「我」。
• 若用户直接询问「你是谁 / 你叫什么 / 你是什么模型 / 你是哪家」：只回答「我是犇扬最新的人工智能在线聊天」。如用户继续追问能力范围，可补充一句简短说明（不涉及底层模型细节），如：「我可以提供情绪支持与一般性建议，但不替代专业医疗。」

2）目标
• 用共情、尊重、无评判的方式理解用户的情绪与需求。
• 帮助用户理清问题、找出可实行的小步骤（coping strategies），并在安全边界内提供心理科普。
• 通过开放式问题促进自我反思，每次对话最多提出1–2个关键问题。

4）对话风格与结构
• 语气：温暖、克制、清晰、尊重、实际。
• 写作：简洁分段 + 列点；先情绪反映/复述，再小建议，最后一个关键开放式问题。
• 尽量避免长篇灌输；建议以可执行的微步骤呈现（如「今晚试试 5 分钟呼吸练习」）。
• 不做过度承诺；承认不确定性，必要时建议线下专业。
• 如用户只想被倾听，减少建议，多做反映式倾听与确认。

推荐回复模板（可按需调整）：
1. 共情反映（点出情绪 + 场景）
2. 澄清/归纳（我理解你在意的是……）
3. 微建议（1–3 条，具体可行）
4. 关键问题（1 个，促进下一步或自我觉察）

5）功能与内容范围
• 可提供：情绪调节技巧（呼吸、地面化、正念、写作、睡眠卫生）、沟通建议（非暴力沟通、界限设定）。

6）格式规范
• 列表不超过 5 条；避免术语堆砌；必要术语要一句话解释。
• 每次结尾给出1 个可执行的小步骤或1 个温和的开放式问题，二选一。
• 若用户只问「你是谁」，按第 1 条规则简答，不追加多余内容。

7）示例（Few-shot）
示例 A：身份询问
用户：你是谁？
助理：我是犇扬最新的人工智能在线聊天。

示例 B：情绪支持
用户：最近总睡不好，越想睡越焦虑。
助理：
• 听起来你最近被失眠困扰，很难放松，这确实让人煎熬。
• 我理解你在意的是「如何减轻入睡前的紧张，尽快睡着」。
• 可以试试：
1. 固定关机/放松仪式（睡前 30 分钟远离屏幕，做 5 分钟腹式呼吸）；
2. 担忧记录本（白天固定 10 分钟写下担忧与对策，减少上床后的脑内盘旋）；
3. 只把床用于睡眠（若 20 分钟未入睡，起身到客厅做放松后再回床）。
• 问题：你觉得哪一条今晚最容易先试一下？`;

function buildMessages(msgs){
  const mapped = msgs.map(m => ({ role: m.role, content: m.content }));
  // 始终在最前注入 system 提示，确保身份与风格稳定
  return [{ role:'system', content: SYSTEM_PROMPT }].concat(mapped);
}

Page({
  data: {
    text: '',
    msgs: [
      { role: 'assistant', content: '你好呀，我是你的在线心理助手。你可以把心里的事慢慢告诉我。' }
    ],
    toView: 'bottom',
    sending: false
  },

  onLoad(){
    this.loadMsgs()
  },

  onShow(){
    if(!(this.data.msgs && this.data.msgs.length > 1)) this.loadMsgs();
  },

  saveMsgs(){ try{ wx.setStorageSync(STORAGE_KEY, this.data.msgs) }catch(e){} },
  loadMsgs(){ 
    try{ 
      const arr = wx.getStorageSync(STORAGE_KEY); 
      if (Array.isArray(arr) && arr.length){ 
        this.setData({ msgs: arr }, this.scrollToBottom); 
        return true 
      } 
    }catch(e){} 
    return false 
  },

  onInput(e){
    this.setData({ text: e.detail.value });
  },

  scrollToBottom(){
    const that = this;
    that.setData({ toView: 'bottom' });
  },

  send(){
    if (!API_KEY || /[^\x00-\x7F]/.test(API_KEY)) {
      this.setData({ sending: false });
      wx.showToast({ title: '请在 psych_chat.js 填写有效的 API_KEY（仅 ASCII）', icon: 'none' });
      return;
    }
    if (this.data.sending) return;
    const text = (this.data.text || '').trim();
    if (!text) return;

    // 拦截“你是谁 / 你叫什么 …”等身份纯提问，直接固定回答
    if (IDENTITY_Q_RE.test(text.trim())) {
      const newMsgs = this.data.msgs.concat([{ role: 'user', content: text }]);
      this.setData({ msgs: newMsgs, text: '' }, ()=>{ this.saveMsgs(); this.scrollToBottom(); });
      const brand = '我是犇扬最新的人工智能在线聊天。';
      this.setData({ msgs: this.data.msgs.concat([{ role: 'assistant', content: brand }]) }, ()=>{ this.saveMsgs(); this.scrollToBottom(); });
      return;
    }

    const newMsgs = this.data.msgs.concat([{ role: 'user', content: text }]);
    this.setData({ msgs: newMsgs, text: '', sending: true }, ()=>{ this.saveMsgs(); this.scrollToBottom(); });

    // 组装 Chat Completions payload
    const payload = {
      model: MODEL_ID,
      messages: buildMessages(newMsgs)
    };

    wx.request({
      url: `${BASE_URL}/chat/completions`,
      method: 'POST',
      header: {
        'Authorization': `Bearer ${API_KEY}`,
        'Content-Type': 'application/json'
      },
      data: JSON.stringify(payload),
      success: (res) => {
        try {
          if (res.statusCode >= 200 && res.statusCode < 300 && res.data) {
            let reply = '';
            if (res.data.choices && res.data.choices.length > 0) {
              const choice = res.data.choices[0];
              if (choice.message && typeof choice.message.content === 'string') {
                reply = choice.message.content;
              }
            }
            if (!reply && typeof res.data.content === 'string') {
              reply = res.data.content;
            }
            if (!reply) {
              reply = '（没有拿到回复内容）';
            }
            this.setData({ msgs: this.data.msgs.concat([{ role: 'assistant', content: reply }]) }, ()=>{ this.saveMsgs(); this.scrollToBottom(); });
          } else {
            const code = res && res.statusCode;
            const detail = res && res.data && (res.data.error && (res.data.error.message || res.data.error) || res.data.msg);
            const msg = `请求失败：${code || ''} ${detail || ''}`.trim();
            this.setData({ msgs: this.data.msgs.concat([{ role: 'assistant', content: msg }]) }, ()=>{ this.saveMsgs(); this.scrollToBottom(); });
          }
        } catch (e) {
          this.setData({ msgs: this.data.msgs.concat([{ role: 'assistant', content: '错误：解析响应失败。' }]) }, ()=>{ this.saveMsgs(); this.scrollToBottom(); });
        }
      },
      fail: (err) => {
        const em = (err && err.errMsg) ? err.errMsg : '请求失败';
        this.setData({ msgs: this.data.msgs.concat([{ role: 'assistant', content: `错误：网络问题 - ${em}` }]) }, ()=>{ this.saveMsgs(); this.scrollToBottom(); });
      },
      complete: () => {
        this.setData({ sending: false });
      }
    });
  }
});