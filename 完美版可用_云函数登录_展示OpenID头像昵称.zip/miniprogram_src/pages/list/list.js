const app = getApp();

function toTagObjects(arr){
  return (arr || []).map(label => ({ label, active: false }));
}

Page({
  data: {
    tagsPool: [],             // [{label:'危机干预', active:false}, ...]
    selectedTags: [],
    priceDesc: 'asc',
    gender: 'all',
    genderLabel: '不限',
    list: []
  },

  onLoad(){
    const src = (app.globalData && app.globalData.tagsPool) || ["危机干预","夫妻关系","亲子关系","个人成长","职业发展"];
    this.setData({ tagsPool: toTagObjects(src) });
  },

  onShow(){
    this.render();
  },

  togglePrice(){
    this.setData({ priceDesc: this.data.priceDesc === 'asc' ? 'desc' : 'asc' }, this.render);
  },

  toggleGender(){
    const next = this.data.gender === 'all' ? 'male' : (this.data.gender === 'male' ? 'female' : 'all');
    this.setData({ gender: next, genderLabel: next === 'all' ? '不限' : (next === 'male' ? '男' : '女') }, this.render);
  },

  toggleTag(e){
    const idx = e.currentTarget.dataset.index;
    const tags = this.data.tagsPool.slice();
    if (tags[idx]) tags[idx].active = !tags[idx].active;
    const selected = tags.filter(t => t.active).map(t => t.label);
    this.setData({ tagsPool: tags, selectedTags: selected }, this.render);
  },

  render(){
    let list = (app.globalData && app.globalData.consultants) ? app.globalData.consultants.slice() : [];
    // 性别过滤
    if (this.data.gender !== 'all') list = list.filter(x => x.gender === this.data.gender);
    // 标签过滤（全部包含）
    if (this.data.selectedTags.length) list = list.filter(x => this.data.selectedTags.every(t => (x.tags || []).includes(t)));
    // 价格排序
    list.sort((a,b) => this.data.priceDesc === 'asc' ? (a.price - b.price) : (b.price - a.price));
    this.setData({ list });
  },

  openProfile(e){
    const id = e.currentTarget.dataset.id;
    if (!app.globalData) return;
    const c = app.globalData.consultants.find(x => x.id === id);
    app.globalData.currentConsultant = c;
    wx.navigateTo({ url: '/pages/profile/profile' });
  }
});
