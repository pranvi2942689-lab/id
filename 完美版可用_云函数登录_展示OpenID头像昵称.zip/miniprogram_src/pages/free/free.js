const app = getApp()
Page({
  data:{ consultants:[] },
  onLoad(){
    // 仅弹一次，可按需改为本地缓存控制
    wx.showModal({
      title:'免费倾诉',
      content:'可以给指定咨询师发送 10 条留言；在咨询师回复后，才能发送下一条。',
      showCancel:false,
      confirmText:'知道了'
    })
    this.setData({ consultants: app.globalData.consultants || [] })
  },
  openChat(e){
    const id = e.currentTarget.dataset.id
    wx.navigateTo({ url: `/pages/free_chat/free_chat?id=${id}` })
  }
})