const app=getApp()
Page({
  data:{orders:[]},
  onShow(){ this.render() },
  render(){
    const wd = (iso)=>{ const d=new Date(iso+'T00:00:00'); return '周' + '日一二三四五六'[d.getDay()]; };
    const list = app.globalData.orders.slice().reverse().map(o=>({
      ...o,
      _showMsg: !!o._showMsg,
      schedule: `${app.humanMD(o.date)}（${wd(o.date)}） ${o.slot}`
    }));
    this.setData({orders: list});
  },

  // 评分
  rate(e){
    const id = +e.currentTarget.dataset.id;
    const type = e.currentTarget.dataset.type; // good | bad
    const o = app.globalData.orders.find(x=>x.id===id);
    if(!o || o.rated) return;
    o.rated = (type==='good'?1:-1);
    const c = o.consultant;
    c.score = (c.score||0) + (type==='good'?1:-1);
    app.toast(type==='good'?'已好评':'已差评');
    this.render();
  },

  // 评论（可带图）
  toggleCmt(e){
    const id = +e.currentTarget.dataset.id;
    const o = app.globalData.orders.find(x=>x.id===id);
    if(!o) return;
    o._showCmt = !o._showCmt;
    o._cmtImgs = o._cmtImgs || [];
    this.render();
  },
  cmtText(e){
    const id = +e.currentTarget.dataset.id;
    const o = app.globalData.orders.find(x=>x.id===id);
    if(!o) return;
    o._cmtText = e.detail.value;
  },
  cmtCancel(e){
    const id = +e.currentTarget.dataset.id;
    const o = app.globalData.orders.find(x=>x.id===id);
    if(!o) return;
    o._showCmt = false; o._cmtText=''; o._cmtImgs=[];
    this.render();
  },
  cmtAddImg(e){
    const id = +e.currentTarget.dataset.id;
    const o = app.globalData.orders.find(x=>x.id===id);
    if(!o) return;
    wx.chooseImage({count:3, sizeType:['compressed'], success: res=>{
      o._cmtImgs = (o._cmtImgs||[]).concat(res.tempFilePaths).slice(0,6);
      this.render();
    }});
  },
  cmtDelImg(e){
    const id = +e.currentTarget.dataset.id;
    const i = +e.currentTarget.dataset.i;
    const o = app.globalData.orders.find(x=>x.id===id);
    if(!o) return;
    (o._cmtImgs||[]).splice(i,1);
    this.render();
  },
  cmtOk(e){
    const id = +e.currentTarget.dataset.id;
    const o = app.globalData.orders.find(x=>x.id===id);
    if(!o || o.commented) return;
    const text = (o._cmtText||'').trim();
    const imgs = (o._cmtImgs||[]);
    if(!text && imgs.length===0){ app.toast('请输入评价或添加图片'); return; }
    const c = o.consultant;
    c.reviews = c.reviews || [];
    c.reviews.unshift({text, imgs, time: Date.now(), user:'匿名用户'});
    o.comment = {text, imgs};
    o.commented = true; o._showCmt=false; o._cmtText=''; o._cmtImgs=[];
    this.render(); app.toast('已提交评价');
  },

  // 打赏
  tip(e){
    const id = +e.currentTarget.dataset.id;
    const o = app.globalData.orders.find(x=>x.id===id);
    if(!o || o.tipped) return;
    wx.showModal({title:'打赏金额', editable:true, placeholderText:'输入金额', success: (res)=>{
      if(res.confirm){
        const v = parseFloat(res.content);
        if(isNaN(v) || v<=0){ app.toast('请输入有效金额'); return; }
        app.globalData.payPurpose = 'tip';
        app.globalData.tipOrderId = id;
        app.globalData.tipTemp = v;
        wx.navigateTo({url:'/pages/pay/pay?amt='+v});
      }
    }});
  },

  // 再来一单
  again(e){
    const id = +e.currentTarget.dataset.id;
    const o = app.globalData.orders.find(x=>x.id===id);
    if(!o) return;
    app.globalData.currentConsultant = o.consultant;
    app.globalData.reOrderDiscount = 0.88;
    wx.navigateTo({url:'/pages/booking/booking'});
  },

  // 临时改约
  res(e){
    const id = +e.currentTarget.dataset.id;
    wx.navigateTo({url:'/pages/reschedule/reschedule?id='+id});
  },

  // 留言
// 留言
toggleMsg(e){
  const id = +e.currentTarget.dataset.id;
  const o = app.globalData.orders.find(x=>x.id===id);
  if(!o) return;
  if(o.method==='online' && !o.paid){ app.toast('线上咨询需先付费'); return; }
  o._showMsg = !o._showMsg;
  this.render();
},
msgText(e){
  const id = +e.currentTarget.dataset.id;
  const o = app.globalData.orders.find(x=>x.id===id);
  if(!o) return;
  o._msgText = e.detail.value;
},
msgSend(e){
  const id = +e.currentTarget.dataset.id;
  const o = app.globalData.orders.find(x=>x.id===id);
  if(!o) return;
  if(o.method==='online' && !o.paid){ app.toast('线上咨询需先付费'); return; }
  const t = (o._msgText||'').trim();
  if(!t){ app.toast('请输入留言'); return; }
  if(o.awaitingReply){ app.toast('请等待咨询师回复后再留言'); return; }
  o.messages = o.messages || [];
  o.messages.push({from:'user', text:t});
  o._msgText = '';
  o.awaitingReply = true;
  o._showMsg = false;
  this.render();
  setTimeout(()=>{
    o.messages.push({from:'consultant', text:'已收到留言，我们会尽快处理与回复。'});
    o.awaitingReply = false;
    this.render();
  }, 800);
}
})
