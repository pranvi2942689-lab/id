Page({
  goPsychChat(){ wx.navigateTo({ url: '/pages/psych_chat/psych_chat' }) },
  goPublic(){ wx.navigateTo({ url: '/pages/public/public' }) },

  goToolbox(){ wx.navigateTo({url:'/pages/toolbox/toolbox'}) },
  goScreening(){ wx.navigateTo({url:'/pages/screening/screening'}) },
  goFree(){ wx.navigateTo({url:'/pages/free/free'}) } ,
  goBook(){ wx.switchTab({url:'/pages/list/list'}) },
  goSupport(){ wx.navigateTo({url:'/pages/support/support'}) },
  goFeedback(){ wx.navigateTo({url:'/pages/feedback/feedback'}) },
  openMap(){
    wx.openLocation({
      latitude: 28.19409,
      longitude: 112.98228,
      name: '湖南犇扬心理咨询有限公司',
      address: '湖南犇扬心理咨询有限公司',
      scale: 16
    })
  }
,
  goArticle(){ wx.navigateTo({url:'/pages/shop/shop'}) }

  ,openPsych(){
    wx.navigateTo({ url: '/pages/psych_chat/psych_chat' });
  }

  ,goMore(){ 
    // 暂时跳转到文章页或反馈页，可按需替换为“更多入口”页面
    wx.navigateTo({url:'/pages/shop/shop'}) 
  }
  ,goScene(e){
    const tag = e.currentTarget.dataset.tag || ''
    // 简单策略：带上 tag 进入量表页；后续可根据 tag 组合推荐内容
    wx.navigateTo({ url: '/pages/screening/screening?scene='+encodeURIComponent(tag) })
  }
,
  goMine(){ wx.navigateTo({ url: '/pages/mine/mine' }); }
})