Page({
  apply(){
    wx.showModal({
      title: '报名提交（模拟）',
      content: '感谢你的热心，我们会在3个工作日内联系你。',
      showCancel: false
    })
  }
})
