const app=getApp()
const weekdays=['周日','周一','周二','周三','周四','周五','周六']
Page({
  data:{b:{}, dates:[], slots:[], ready:false},

  updateSlots(){
    // 基础时段 9:00–20:00（整点）
    const base=[]
    for(let h=9; h<20; h++){
      base.push(`${(''+h).padStart(2,'0')}:00–${(''+(h+1)).padStart(2,'0')}:00`)
    }
    const { b } = this.data
    if(!b.date){
      this.setData({ slots: base })
      return
    }
    const todayISO = app.toLocalISO(new Date())
    let filtered = base
    if(b.date === todayISO){
      const now = new Date()
      const curH = now.getHours()
      filtered = base.filter(s => {
        const startH = parseInt(s.slice(0,2),10)
        return startH > curH
      })
    }
    let newB = { ...b }
    if(newB.slot && !filtered.includes(newB.slot)){
      newB.slot = null
    }
    this.setData({ slots: filtered, b: newB })
  },

  onShow(){
    const now = new Date()
    const dates=[]
    for(let i=0;i<8;i++){
      const d = new Date()
      d.setHours(0,0,0,0); d.setDate(now.getDate()+i)
      const iso = app.toLocalISO(d)
      dates.push({iso, label:`${weekdays[d.getDay()]} ${d.getMonth()+1}/${d.getDate()}`})
    }
    this.setData({ b:{...app.globalData.booking}, dates }, () => { this.updateSlots(); this.validate(); })
  },

  pickMethod(e){ const method=e.currentTarget.dataset.m; this.setData({b:{...this.data.b, method}}, this.validate) },
  pickDate(e){ const date=e.currentTarget.dataset.iso; this.setData({b:{...this.data.b, date}}, ()=>{ this.updateSlots(); this.validate(); }) },
  pickSlot(e){ const slot=e.currentTarget.dataset.s; this.setData({b:{...this.data.b, slot}}, this.validate) },
  onName(e){ this.setData({b:{...this.data.b, name:e.detail.value.trim()}}, this.validate) },
  onPhone(e){ this.setData({b:{...this.data.b, phone:e.detail.value.replace(/\D+/g,'')}}, this.validate) },

  validate(){
    const {method,date,slot,name,phone}=this.data.b
    const ok = !!method && !!date && !!slot && !!name && /^([0-9]{6,20}|1[3-9]\d{9})$/.test(phone)
    this.setData({ready:ok})
  },

  goConfirm(){ if(!this.data.ready) return; app.globalData.booking=this.data.b; wx.navigateTo({url:'/pages/confirm/confirm'}) }
})
