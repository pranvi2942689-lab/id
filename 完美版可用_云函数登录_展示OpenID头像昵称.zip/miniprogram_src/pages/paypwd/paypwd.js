const app=getApp()
Page({
  data:{v:''},
  onLoad(q){ this.amount = q.amt || '0' },
  onInput(e){
    const v = (e.detail.value||'').replace(/\D+/g,'').slice(0,6)
    this.setData({v})
    if(v.length===6){
      if(app.globalData.payPurpose==='reservation'){
        this.createOrder(true)
        wx.showModal({title:'预约结果', content:'支付成功', showCancel:false, success:()=>{
          app.globalData.reOrderDiscount=null
          wx.switchTab({url:'/pages/orders/orders'})
        }})
      }else{
        const o = app.globalData.orders.find(x=> x.id===app.globalData.tipOrderId)
        if(o){ o.tipped=true; o.tipAmount=(o.tipAmount||0)+(+app.globalData.tipTemp) }
        app.globalData.payPurpose='reservation';
        app.globalData.tipOrderId=null;
        app.globalData.tipTemp=0;
        wx.showModal({title:'打赏', content:'打赏成功，感谢支持！', showCancel:false, success:()=>{
          wx.switchTab({url:'/pages/orders/orders'})
        }})
      }
    }
  },
  createOrder(paid){
    const c = app.globalData.currentConsultant
    const b = app.globalData.booking
    app.globalData.orders.push({id:(Date.now()*1000 + Math.floor(Math.random()*1000)), consultant:c, price:c.price, date:b.date, slot:b.slot, method:b.method, paid:!!paid, rescheduled:false, rated:null, commented:false, tipped:false, tipAmount:0, messages:[], awaitingReply:false})
  }
})
