
const weekdays = ["周日","周一","周二","周三","周四","周五","周六"];
function pad(n){return (n<10?'0':'')+n;}
function toLocalISO(d){return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`;}
function humanDate(iso){ if(!iso) return "—"; const d = new Date(iso+"T00:00:00"); return `${d.getFullYear()}-${d.getMonth()+1}-${d.getDate()}`; }

Page({
  data:{
    pageTitle:"犇扬心理",
    canBack:false,
    activeView:"home",
    tabbarVisible:true,
    bottom:{visible:false,text:"",enabled:false,totalVisible:false,amountText:"¥0"},
    priceDesc:"asc",
    gender:"all",
    genderText:"不限",
    tagsPool:["危机干预","夫妻关系","亲子关系","个人成长","职业规划","青少年心理"],
    selectedTags:{},
    consultants:[
      { id:1, name:"唐海波", gender:"male", price:3000, title:"中南大学心理健康教育与咨询专家、教授、临床心理学博士", time:"需提前一天预约", tags:["危机干预"], long:"【基本情况】教授，临床心理学博士。\n【擅长】危机干预、急性应激、哀伤辅导。\n【提示】高峰期需提前一天预约。", score:0, reviews:[], photo:"/assets/tang.jpg" },
      { id:2, name:"邹美红", gender:"female", price:2000, title:"国家二级心理咨询师、资深法律工作者", time:"周一到周日 9:00～20:00", tags:["夫妻关系","亲子关系"], long:"【基本情况】国家二级心理咨询师。\n【擅长】婚姻家庭、亲子沟通、家庭系统。\n【风格】温和而有力量，重视来访者的资源。", score:0, reviews:[], photo:"/assets/zou.jpg" },
      { id:3, name:"罗飞", gender:"female", price:1200, title:"湖南省高校心理协会 / 心理咨询师", time:"周一到周日 9:00～20:00", tags:["个人成长","亲子关系","职业规划","青少年心理"],
        long:"罗飞，国家二级心理咨询师、国家一级人力资源师，拥有企业与高校双背景：曾任高校心健中心负责人、集团HR/运营总监15年，系统受训于CBT（中德班/北大回龙观）、NLP、艾瑞克森催眠与心理测量。\n累计个案千余小时、督导近2000小时，主讲百余场讲座并长期参与公益；与政府有合作，为华润集团提供企业EAP方案并负责落地执行。\n擅长个人成长、亲子/亲密关系、职业规划与人岗匹配，风格沉稳高效、洞察力强，直指关键并给出可执行的改变路径，效果可感可见。",
        score:0, reviews:[], photo:"/assets/luo.jpg" }
    ],
    filteredConsultants:[],
    currentConsultant:{},
    reviews:[],

    // booking
    booking:{method:null,date:null,slot:null,name:"",phone:""},
    dateList:[], slotList:[],
    payMode:"postpay",
    payAmount:0, payPurpose:"reservation",
    pwdLength:0,

    // orders
    orders:[],

    // reschedule
    reschedule:{date:null,slot:null,targetId:null},
    reDateList:[],

    // feedback
    fbText:"",
    fbImages:[],

    // support
    supportMsgs:[],
    chatText:"",
    chatTop:56,
    chatIntoView:""
  },

  onLoad(){
    this.refreshFilter();
    this.updateBottom();
    this.setData({ md: getApp().humanMD, wd: (iso)=>['周日','周一','周二','周三','周四','周五','周六'][new Date((iso||'')+'T00:00:00').getDay()] });
  },

  /* ====== Nav ====== */
  onBack(){
    const order = ["home","list","profile","booking","confirm","pay","paypwd","orders","reschedule","feedback","article","support"];
    // naive: go home if not home
    if(this.data.activeView==="home"){return;}
    if(this.data.activeView==="support" || this.data.activeView==="article"){
      this.switchTo("home");return;
    }
    if(this.data.activeView==="orders"){ this.switchTo("home"); return; }
    if(this.data.activeView==="profile"){ this.switchTo("list"); return; }
    if(this.data.activeView==="booking"){ this.switchTo("profile"); return; }
    if(this.data.activeView==="confirm"){ this.switchTo("booking"); return; }
    if(this.data.activeView==="pay" || this.data.activeView==="paypwd"){ this.switchTo("confirm"); return; }
    if(this.data.activeView==="reschedule"){ this.switchTo("orders"); return; }
    if(this.data.activeView==="feedback"){ this.switchTo("home"); return; }
  },

  switchTo(v){
    const pageTitleMap={home:"犇扬心理",list:"预约咨询",profile:"预约咨询",booking:"预约咨询",confirm:"确认预约信息",pay:"支付",paypwd:"输入支付密码",orders:"咨询情况",reschedule:"临时改约",feedback:"客户回访表",article:"我们什么时候需要心理咨询",support:"咨询客服"};
    this.setData({
      activeView:v,
      pageTitle:pageTitleMap[v]||"犇扬心理",
      canBack: v!=="home",
      tabbarVisible: !["profile","booking","confirm","pay","paypwd","support"].includes(v)
    });
    if(v==="orders")this.refreshOrders();
    if(v==="support")this.updateChatTop();
    this.updateBottom();
  },

  switchTab(e){
    const tab = e.currentTarget.dataset.tab;
    if(tab) this.switchTo(tab);
  },

  /* ===== 首页入口 ===== */
  goBook(){ this.switchTo("list"); },
  goSupport(){ this.switchTo("support"); },
  goFeedback(){ this.switchTo("feedback"); },
  goArticle(){ this.switchTo("article"); },

  openMap(){
    wx.showToast({title:"已尝试打开地图", icon:"none"});
  },

  /* ===== 筛选 ===== */
  togglePrice(){
    const next = this.data.priceDesc==="asc"?"desc":"asc";
    this.setData({priceDesc:next});
    this.refreshFilter();
  },
  toggleGender(){
    const order = {all:"male",male:"female",female:"all"};
    const next = order[this.data.gender];
    this.setData({gender:next, genderText: next==="all"?"不限":(next==="male"?"男":"女")});
    this.refreshFilter();
  },
  toggleTag(e){
    const i = e.currentTarget.dataset.index;
    const selected = Object.assign({}, this.data.selectedTags);
    selected[i] = !selected[i];
    this.setData({selectedTags:selected});
    this.refreshFilter();
  },
  refreshFilter(){
    const selected = Object.keys(this.data.selectedTags).filter(k=>this.data.selectedTags[k]).map(k=>this.data.tagsPool[k]);
    let list = this.data.consultants.slice();
    if(selected.length){
      list = list.filter(c => selected.every(t=>c.tags.includes(t)));
    }
    if(this.data.gender!=="all"){
      list = list.filter(c=>c.gender===this.data.gender);
    }
    list.sort((a,b)=> this.data.priceDesc==="desc" ? (b.price-a.price) : (a.price-b.price));
    this.setData({filteredConsultants:list});
  },

  /* ===== 详情 ===== */
  openProfile(e){
    const id = e.currentTarget.dataset.id;
    const c = this.data.filteredConsultants.find(x=>x.id===id);
    this.setData({currentConsultant:c, reviews:c.reviews||[]});
    this.switchTo("profile");
  },

  /* ===== 预约 ===== */
  openBooking(){
    const booking = {method:null,date:null,slot:null,name:"",phone:""};
    const dateList=[];
    for(let i=0;i<8;i++){
      const d=new Date(); d.setHours(0,0,0,0); d.setDate(d.getDate()+i);
      dateList.push({iso:toLocalISO(d), label:`${weekdays[d.getDay()]} ${d.getMonth()+1}/${d.getDate()}`});
    }
    const slotList=[];
    for(let h=9;h<20;h++){ slotList.push(`${pad(h)}:00–${pad(h+1)}:00`); }
    this.setData({booking,dateList,slotList});
    this.switchTo("booking");
  },
  pickMethod(e){ const m=e.currentTarget.dataset.method; this.setData({['booking.method']:m}); this.updateBottom(); },
  pickDate(e){ const iso=e.currentTarget.dataset.iso; this.setData({['booking.date']:iso}); this.updateBottom(); },
  pickSlot(e){ const s=e.currentTarget.dataset.slot; this.setData({['booking.slot']:s}); this.updateBottom(); },
  onNameInput(e){ this.setData({['booking.name']:(e.detail.value||'').trim()}); this.updateBottom(); },
  onPhoneInput(e){ const v=(e.detail.value||'').replace(/\D+/g,''); this.setData({['booking.phone']:v}); this.updateBottom(); },

  /* ===== 确认 ===== */
  openConfirm(){
    const b=this.data.booking, c=this.data.currentConsultant;
    const confirmDatetime = `${humanDate(b.date)} ${b.slot}（${b.method==='offline'?'线下咨询':'线上咨询'}）`;
    const payMode = b.method==='online' ? 'prepay' : 'postpay';
    this.setData({confirmDatetime,payMode});
    this.switchTo("confirm");
  },
  pickPayMode(e){
    const m=e.currentTarget.dataset.mode;
    this.setData({payMode:m});
    this.updateBottom();
  },

  /* ===== 支付 ===== */
  goPwd(){ this.switchTo("paypwd"); this.setData({pwdLength:0}); },
  onPwdInput(e){
    const v = (e.detail.value||'').replace(/\D+/g,'').slice(0,6);
    this.setData({pwdLength:v.length});
    if(v.length===6){
      if(this.data.payPurpose==='reservation'){
        this.createOrder(true);
        this.showDialog({title:'预约结果', text:'支付成功', okText:'确认', showCancel:false, onOk:()=>{ this.setData({reOrderDiscount:null}); this.switchTo('orders'); }});
      }else{
        const orders=this.data.orders.slice();
        const idx=orders.findIndex(o=>o.id===this.data.tipOrderId);
        if(idx>-1){ orders[idx].tipped=true; orders[idx].tipAmount=(orders[idx].tipAmount||0)+this.data.tipTemp; }
        this.setData({orders});
        this.showDialog({title:'打赏', text:'打赏成功，感谢支持！', okText:'确认', showCancel:false, onOk:()=>{ this.switchTo('orders'); }});
      }
    }
  },

  /* ===== 底部条逻辑 ===== */
  updateBottom(){
    const v=this.data.activeView;
    let bottom={visible:false,text:"",enabled:false,totalVisible:false,amountText:"¥0"};
    if(v==='profile'){
      bottom={visible:true,text:"预约咨询",enabled:true,totalVisible:false,amountText:""};
    }else if(v==='booking'){
      const b=this.data.booking;
      const ok = !!(b.method && b.date && b.slot && b.name && /^([0-9]{6,20}|1[3-9]\d{9})$/.test(b.phone));
      bottom={visible:true,text: ok?'开始预约':'请补充预约时间、咨询方式和联系方式', enabled:ok, totalVisible:false, amountText:""};
    }else if(v==='confirm'){
      const pre=this.data.payMode==='prepay';
      const price = this.getCurrentPrice();
      bottom={visible:true,text: pre?'立即支付':'立即预约', enabled:true, totalVisible:pre, amountText:`¥${price}`};
    }else if(v==='pay' || v==='paypwd'){
      bottom={visible:true,text:"",enabled:false,totalVisible:true,amountText:`¥${this.data.payAmount||this.getCurrentPrice()}`};
    }
    this.setData({bottom});
  },
  onBottomTap(){
    const v=this.data.activeView;
    if(v==='profile'){ this.openBooking(); }
    else if(v==='booking'){ const b=this.data.booking; if(b.method&&b.date&&b.slot&&b.name&&/^([0-9]{6,20}|1[3-9]\d{9})$/.test(b.phone)){ this.openConfirm(); } }
    else if(v==='confirm'){
      const pre=this.data.payMode==='prepay';
      if(pre){
        this.setData({payPurpose:'reservation', payAmount:this.getCurrentPrice()});
        this.switchTo('pay');
      }else{
        this.createOrder(false);
        this.showDialog({title:'预约成功',text:'工作人员马上电话联系您。',okText:'确认',showCancel:false,onOk:()=>{this.switchTo('orders');}});
      }
    }
  },
  getCurrentPrice(){
    const base=this.data.currentConsultant?.price||0;
    return (this.data.payMode==='prepay' && this.data.reOrderDiscount) ? Math.round(base*this.data.reOrderDiscount) : base;
  },

  /* ===== 订单 ===== */
  createOrder(paid){
    const b=this.data.booking, c=this.data.currentConsultant;
    const order={
      id: Date.now(),
      consultant: JSON.parse(JSON.stringify(c)),
      price: c.price,
      date: b.date, slot: b.slot, method: b.method,
      dateHuman: humanDate(b.date), weekday: '周'+'日一二三四五六'[new Date(b.date+'T00:00:00').getDay()], weekday: weekdays[new Date(b.date+'T00:00:00').getDay()],
      paid: !!paid, rescheduled:false, rated:null, commented:false, tipped:false, tipAmount:0, messages:[], awaitingReply:false
    };
    const orders=this.data.orders.concat(order);
    this.setData({orders});
  },
  refreshOrders(){
    // noop for now
  },
  orderAction(e){
    const act=e.currentTarget.dataset.act;
    const id=e.currentTarget.dataset.id;
    const orders=this.data.orders.slice();
    const idx=orders.findIndex(o=>o.id===id);
    if(idx===-1) return;
    const o=orders[idx];
    const c=this.data.consultants.find(x=>x.id===o.consultant.id);
    const setOrders=()=>this.setData({orders});
    if(act==='good' && !o.rated){ o.rated='good'; c.score++; setOrders(); this.refreshFilter(); if(this.data.currentConsultant.id===c.id){ this.setData({'currentConsultant.score':c.score}); } this.toast('已好评'); }
    else if(act==='bad' && !o.rated){ o.rated='bad'; c.score--; setOrders(); this.refreshFilter(); if(this.data.currentConsultant.id===c.id){ this.setData({'currentConsultant.score':c.score}); } this.toast('已差评'); }
    else if(act==='comment' && !o.commented){ o._showCmt=true; setOrders(); }
    else if(act==='cmtCancel'){ o._showCmt=false; setOrders(); }
    else if(act==='cmtOk' && !o.commented){ 
      const text=o._cmtText||""; const imgs=o._cmtImgs||[];
      if(!text && imgs.length===0){ this.toast("写点内容或传张图片吧"); return; }
      c.reviews=c.reviews||[]; c.reviews.push({text,imgs:[...imgs]}); o.commented=true; o._showCmt=false;
      setOrders(); if(this.data.currentConsultant.id===c.id){ this.setData({reviews:c.reviews}); }
      this.toast("已提交评价");
    }
    else if(act==='tip' && !o.tipped){ this.setData({payPurpose:'tip', tipOrderId:id, tipTemp:0}); this.showSheet(true); }
    else if(act==='again'){ this.setData({currentConsultant:c, reOrderDiscount:0.88}); this.openBooking(); }
    else if(act==='res'){ this.openRescheduleFor(id); }
    else if(act==='msg'){ o._showMsg=!o._showMsg; setOrders(); }
    else if(act==='msgSend'){ 
      const userCount=(o.messages||[]).filter(m=>m.from==='user').length;
      if(userCount>=5){ this.toast('最多留言 5 条'); return; }
      if(o.awaitingReply){ this.toast('请等待咨询师回复后再留言'); return; }
      const text=(o._msgText||'').trim(); if(!text){ this.toast('请输入留言内容'); return; }
      o.messages=o.messages||[]; o.messages.push({from:'user',text}); o.awaitingReply=true; o._msgText=""; setOrders();
      setTimeout(()=>{ o.messages.push({from:'consultant',text:'已收到您的留言，我们会尽快处理与回复。'}); o.awaitingReply=false; setOrders(); }, 800);
    }
  },
  chooseCmtImages(e){
    const id=e.currentTarget.dataset.id;
    const orders=this.data.orders.slice();
    const idx=orders.findIndex(o=>o.id===id);
    if(idx===-1) return;
    const o=orders[idx];
    const remain=9 - ((o._cmtImgs||[]).length);
    const cnt= remain>0 ? remain : 0;
    if(cnt<=0){ this.toast("最多 9 张"); return; }
    wx.chooseImage({count:cnt, success: res=>{
      o._cmtImgs=(o._cmtImgs||[]).concat(res.tempFilePaths);
      this.setData({orders});
    }});
  },
  onCmtInput(e){
    const id=e.currentTarget.dataset.id;
    const orders=this.data.orders.slice();
    const idx=orders.findIndex(o=>o.id===id); if(idx===-1) return;
    orders[idx]._cmtText=e.detail.value;
    this.setData({orders});
  },
  onMsgInput(e){
    const id=e.currentTarget.dataset.id;
    const orders=this.data.orders.slice();
    const idx=orders.findIndex(o=>o.id===id); if(idx===-1) return;
    orders[idx]._msgText=e.detail.value;
    this.setData({orders});
  },

  /* ===== 改约 ===== */
  openRescheduleFor(orderId){
    const start=new Date(); start.setHours(0,0,0,0); start.setDate(start.getDate()+1);
    const reDateList=[];
    for(let i=0;i<7;i++){ const d=new Date(start); d.setDate(start.getDate()+i); reDateList.push({iso:toLocalISO(d),label2:`${d.getMonth()+1}/${d.getDate()}`}); }
    this.setData({reschedule:{date:null,slot:null,targetId:orderId}, reDateList});
    this.switchTo('reschedule');
  },
  pickReDate(e){ const iso=e.currentTarget.dataset.iso; this.setData({['reschedule.date']:iso}); },
  pickReSlot(e){ const s=e.currentTarget.dataset.slot; this.setData({['reschedule.slot']:s}); },
  doneReschedule(){
  const r=this.data.reschedule;
  if(!r.date || !r.slot){ this.toast('请先选择新的日期和时间段'); return; }
  const orders=this.data.orders.slice();
  const idx=orders.findIndex(o=>o.id===r.targetId);
  if(idx>-1){
    orders[idx].date = r.date;
    orders[idx].slot = r.slot;
    orders[idx].dateHuman = humanDate(r.date);
    orders[idx].weekday = weekdays[new Date(r.date+'T00:00:00').getDay()];
    orders[idx].rescheduled = true;
  }
  this.setData({orders});
  this.showDialog({title:'改约成功', text:'我们已为您改到新的时间。', showCancel:false, onOk:()=>{ this.switchTo('orders'); }});
},
  /* ===== 反馈 ===== */
  onFbInput(e){ this.setData({fbText:e.detail.value}); },
  chooseFbImages(){
    const remain = 9 - this.data.fbImages.length;
    if(remain<=0){ this.toast('最多 9 张'); return; }
    wx.chooseImage({
      count:remain,
      success: res=>{
        const add = res.tempFilePaths.map(p=>({path:p}));
        this.setData({fbImages: this.data.fbImages.concat(add)});
      }
    });
  },
  removeFbImage(e){
    const i=e.currentTarget.dataset.index;
    const arr=this.data.fbImages.slice(); arr.splice(i,1); this.setData({fbImages:arr});
  },
  submitFeedback(){
    if(!this.data.fbText && this.data.fbImages.length===0){ this.toast('请填写内容或添加截图'); return; }
    this.setData({fbText:"", fbImages:[]}); this.toast('已提交'); this.switchTo('home');
  },

  /* ===== 客服 ===== */
  updateChatTop(){
    const sys = wx.getSystemInfoSync();
    const top=56; // 简化版
    this.setData({chatTop:top});
    if(this.data.supportMsgs.length===0){
      this.setData({supportMsgs:[{from:'kefu',text:'您好，我是客服小犇，有什么可以帮您？'}]});
    }
    this.scrollChatBottom();
  },
  onChatInput(e){ this.setData({chatText:e.detail.value}); },
  sendChat(){
    const val=(this.data.chatText||"").trim(); if(!val) return;
    const msgs=this.data.supportMsgs.concat([{from:'me',text:val}]);
    this.setData({supportMsgs:msgs, chatText:""});
    this.scrollChatBottom();
    setTimeout(()=>{
      const msgs2=this.data.supportMsgs.concat([{from:'kefu',text:'66666'}]);
      this.setData({supportMsgs:msgs2}); this.scrollChatBottom();
    },600);
  },
  scrollChatBottom(){
    const id = 'msg' + (this.data.supportMsgs.length-1);
    this.setData({chatIntoView:id});
  },

  /* ===== UI helpers ===== */
  showDialog({title,text,okText='确认',cancelText='取消',showCancel=true,onOk,onCancel}){
    this.setData({dialog:{show:true,title,text,okText,cancelText,showCancel}});
    this._dlgOk = onOk; this._dlgCancel=onCancel;
  },
  dialogOk(){ this.setData({dialog:{show:false}}); if(typeof this._dlgOk==='function') this._dlgOk(); },
  dialogCancel(){ this.setData({dialog:{show:false}}); if(typeof this._dlgCancel==='function') this._dlgCancel(); },
  showSheet(show){ this.setData({sheet:{show}}); },
  onTipInput(e){ this.setData({tipTemp: parseFloat(e.detail.value||'0')||0}); },
  tipCancel(){ this.showSheet(false); },
  tipOk(){
    const v = this.data.tipTemp;
    if(!(v>0)){ this.toast('请输入正确金额'); return; }
    this.showSheet(false);
    this.setData({payAmount:v}); this.switchTo('paypwd');
  },
  toast(text){ this.setData({toast:{show:true,text}}); setTimeout(()=>this.setData({toast:{show:false,text:''}}), 1500); },

  /* 入口按钮 */
  onReady(){
    // 绑定底部按钮点击（由于用 view 模拟按钮）
  }

  ,openPsych(){
    wx.navigateTo({ url: '/pages/psych_chat/psych_chat' });
  }
});
