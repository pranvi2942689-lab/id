Page({
  data:{},
  onShow(){},
  // 如果需要企业微信客服，可改为 wx.openCustomerServiceChat
  openKefuByAPI(){
    wx.openCustomerServiceChat({
      extInfo: { url: 'https://your-kefu-url.example.com' },
      corpId: '你的企业微信corpId',
      fail: () => { wx.showToast({title:'客服打开失败', icon:'none'}) }
    })
  }
})