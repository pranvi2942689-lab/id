const app = getApp()
const APP_NAME = '犇扬心理';
// —— 以下三项和 psych_chat.js 一致：前端直连仅用于测试 ——
// 若你有自己的后端代理，请把 BASE_URL 改成你的接口地址，并去掉 Authorization 头。
const BASE_URL = "https://openai.qiniu.com/v1";
const MODEL_ID = "gpt-oss-120b";
const API_KEY = "在这里填你的测试Key";

function ensureState(id){
  const talks = app.globalData.freeTalks || (app.globalData.freeTalks = {})
  if(!talks[id]) talks[id] = { count:0, messages:[], waiting:false }
  return talks[id]
}
// 只在该对话的第一条助手回复里自报“我是{姓名}”，之后禁止再自称
function buildMessages(consultant, history){
  const assistantCount = (history || []).filter(m => m && m.from === 'consultant').length
  const needIntro = assistantCount === 0
  const msgs = []
  const rule = needIntro
    ? `你现在扮演心理咨询师：${consultant.name}。这轮对话中，仅在你本次的第一条回复时，第一句必须以“我是${consultant.name}，”开头，然后直接解答来访者问题；后续任何回复都禁止再以“我是${consultant.name}”或类似方式自称。`
    : `你现在扮演心理咨询师：${consultant.name}。这轮对话中，禁止再以“我是${consultant.name}”或类似方式自称，直接专业、温和地用中文解答即可。`
  msgs.push({ role:'system', content: rule + ' 回复要简洁具体，避免诊断或敏感医疗建议。'})
  ;(history||[]).forEach(m=>{
    if(!m || !m.text) return
    msgs.push({ role: m.from==='user' ? 'user' : 'assistant', content: m.text })
  })
  return msgs
}

Page({
  data:{ consultant:null, state:{count:0,messages:[],waiting:false}, _text:'', title:'免费倾诉' },
  onLoad(options){
    const id = Number(options.id)
    const c = (app.globalData.consultants||[]).find(x=>x.id===id)
    if(!c){ app.toast('未找到该咨询师'); wx.navigateBack(); return }
    const state = ensureState(id)
    this.setData({ consultant:c, state, _text:'', title: '与 ' + c.name + ' 倾诉' })
  },
  onShow(){
    if(this.data.consultant){
      const st = ensureState(this.data.consultant.id)
      this.setData({ state: st })
    }
  },
  onText(e){ this.setData({_text: e.detail.value}) },
  send(){
    const txt = (this.data._text||'').trim()
    if(!txt) return app.toast('请输入内容')
    const id = this.data.consultant.id
    const st = ensureState(id)
    if(st.count >= 10) return app.toast('已达到 10 条上限')
    if(st.waiting) return app.toast('请等待咨询师回复后再发送下一条')

    // 1) 写入用户消息
    st.messages.push({ from:'user', text:txt, ts:Date.now() })
    st.count += 1
    st.waiting = true
    this.setData({ state: st, _text:'' })

    // 2) 调用 API 生成咨询师回复
    if(!API_KEY || /[^\x00-\x7F]/.test(API_KEY)){
      app.toast('请在 free_chat.js 配置 API_KEY（仅用于测试）')
      st.waiting = false
      this.setData({ state: st })
      return
    }
    const payload = {
      model: MODEL_ID,
      messages: buildMessages(this.data.consultant, st.messages)
    }
    wx.request({
      url: `${BASE_URL}/chat/completions`,
      method: 'POST',
      header: {
        'Authorization': `Bearer ${API_KEY}`,
        'Content-Type': 'application/json'
      },
      data: JSON.stringify(payload),
      success: (res) => {
        let reply = ''
        try{
          if (res.statusCode >= 200 && res.statusCode < 300 && res.data){
            if (res.data.choices && res.data.choices.length > 0){
              const choice = res.data.choices[0]
              if (choice.message && typeof choice.message.content === 'string'){
                reply = choice.message.content
              }
            }
            if (!reply && typeof res.data.content === 'string'){ reply = res.data.content }
          }else{
            const code = res && res.statusCode
            const detail = res && res.data && (res.data.error && (res.data.error.message || res.data.error) || res.data.msg)
            reply = `请求失败：${code||''} ${detail||''}`.trim()
          }
        }catch(e){
          reply = '（解析响应失败）'
        }

        // 额外保险：如果不是首次助理回复，去掉开头“我是{姓名}，”
        const assistantCount = st.messages.filter(m=>m.from==='consultant').length
        if(assistantCount > 0 && reply){
          const name = this.data.consultant.name
          const reg = new RegExp('^\\s*我是(?:' + name + ')\\s*[,， ]?')
          reply = reply.replace(reg, '')
        }

        st.messages.push({ from:'consultant', text: reply || '（空响应）', ts: Date.now() })
        st.waiting = false
        this.setData({ state: st })
      },
      fail: (err) => {
        const em = (err && err.errMsg) ? err.errMsg : '网络错误'
        st.messages.push({ from:'consultant', text: `错误：${em}`, ts: Date.now() })
        st.waiting = false
        this.setData({ state: st })
      }
    })
  }
})