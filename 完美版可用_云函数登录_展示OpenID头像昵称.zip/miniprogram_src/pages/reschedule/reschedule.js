const app=getApp()
Page({
  onLoad(q){ this.id=+q.id },
  data:{dates:[], slots:[], date:null, slot:null},
  onShow(){
    const start=new Date(); start.setDate(start.getDate()+1); start.setHours(0,0,0,0)
    const dates=[]; for(let i=0;i<7;i++){ const d=new Date(start); d.setDate(start.getDate()+i); dates.push({iso:app.toLocalISO(d), label:`${d.getMonth()+1}/${d.getDate()}`}) }
    const slots=[]; for(let h=9;h<20;h++){ slots.push(`${(''+h).padStart(2,'0')}:00–${(''+(h+1)).padStart(2,'0')}:00`) }
    this.setData({dates, slots})
  },
  pickDate(e){ this.setData({date:e.currentTarget.dataset.iso}) },
  pickSlot(e){ this.setData({slot:e.currentTarget.dataset.s}) },
  done(){
    const o = app.globalData.orders.find(x=>x.id===this.id); if(!o) return;
    if(!this.data.date || !this.data.slot){ app.toast('请先选择新的日期和时间段'); return; }
    o.date=this.data.date; o.slot=this.data.slot; o.rescheduled=true;
    wx.showModal({title:'改约成功', content:'我们已为您改到新的时间。', showCancel:false, success:()=> wx.switchTab({url:'/pages/orders/orders'})})
  }
})
