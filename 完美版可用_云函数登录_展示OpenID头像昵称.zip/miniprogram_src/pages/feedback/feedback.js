const app=getApp()
Page({
  data:{text:'', imgs:[]},
  onText(e){ this.setData({text:e.detail.value}) },
  choose(){ wx.chooseImage({count:9-this.data.imgs.length, success:(res)=>{ this.setData({imgs: this.data.imgs.concat(res.tempFilePaths)}) }}) },
  submit(){ if(!this.data.text.trim() && this.data.imgs.length===0){ app.toast('请填写内容或添加截图'); return; } this.setData({text:'', imgs:[]}); app.toast('已提交'); setTimeout(()=> ((getApp&&getApp().safeNavigateBack)?getApp().safeNavigateBack(1, '/pages/home/home'):(function(){try{const _p=getCurrentPages(); if(_p && _p.length>1){((getApp&&getApp().safeNavigateBack)?getApp().safeNavigateBack(1, '/pages/home/home'):(function(){try{const _p=getCurrentPages(); if(_p && _p.length>1){wx.navigateBack({delta:1});} else {wx.switchTab({url:'/pages/home/home', fail:()=>wx.reLaunch({url:'/pages/home/home'})});}}catch(e){wx.switchTab({url:'/pages/home/home', fail:()=>wx.reLaunch({url:'/pages/home/home'})});}})());} else {wx.switchTab({url:'/pages/home/home', fail:()=>wx.reLaunch({url:'/pages/home/home'})});}}catch(e){wx.switchTab({url:'/pages/home/home', fail:()=>wx.reLaunch({url:'/pages/home/home'})});}})()), 300) }
})
