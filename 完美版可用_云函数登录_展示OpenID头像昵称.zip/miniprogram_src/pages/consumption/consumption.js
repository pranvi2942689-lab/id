const app = getApp();
Page({
  data:{
    total:'0', totalValue:0, tips:'0',
    progress3600:0, leftToNext:'0',
    unlocked1200:false, unlocked2400:false, unlocked3600:false,
    lotteryDrawn1200:false, lotteryDrawn2400:false, lotteryDrawn3600:false
  },
  onShow(){
    const paid = (app.globalData.orders || []).filter(o=>o.paid);
    const tipSum = paid.reduce((s,o)=>s+(o.tipAmount||0),0);
    const amtSum = paid.reduce((s,o)=>s+(parseFloat(o.price)||0),0);
    const total = amtSum + tipSum;

    // 金额进度（按 3600 封顶展示）
    const progress3600 = Math.max(0, Math.min(100, Math.floor(total/3600*100)));
    let leftToNext = 0;
    if (total<1200) leftToNext = 1200-total;
    else if (total<2400) leftToNext = 2400-total;
    else if (total<3600) leftToNext = 3600-total;
    else leftToNext = 0;

    // 订单次数进度（3 次）
    const count = paid.length;
    const progressCount = Math.max(0, Math.min(100, Math.floor(count/3*100)));
    const leftCount = count>=3 ? 0 : 3-count;

    // 明细列表
    const list = paid.map(o=>({date:o.date, title:o.consultant?.name||'', amount:o.price}));

    this.setData({
      total: app.money(total), totalValue: total, tips: app.money(tipSum),
      progress3600, leftToNext: app.money(leftToNext),
      unlocked1200: total >= 1200,
      unlocked2400: total >= 2400,
      unlocked3600: total >= 3600,
      lotteryDrawn1200: !!app.globalData.lotteryDrawn1200,
      lotteryDrawn2400: !!app.globalData.lotteryDrawn2400,
      lotteryDrawn3600: !!app.globalData.lotteryDrawn3600,
      list, count, progressCount, unlockedCount: count>=3, leftCount
    });
  },
  goLottery(e){
    const tier = (e && e.currentTarget && e.currentTarget.dataset && e.currentTarget.dataset.tier) || '3600';
    const unlocked = (tier==='1200' ? this.data.unlocked1200 : (tier==='2400' ? this.data.unlocked2400 : this.data.unlocked3600));
    const drawn = (tier==='1200' ? this.data.lotteryDrawn1200 : (tier==='2400' ? this.data.lotteryDrawn2400 : this.data.lotteryDrawn3600));
    if (!unlocked) { app.toast && app.toast(`满 ¥${tier} 才可抽奖哦`); return; }
    if (drawn) { app.toast && app.toast('已抽过奖啦'); return; }
    wx.navigateTo({ url:'/pages/lottery/lottery?tier=' + tier });
  }
});
