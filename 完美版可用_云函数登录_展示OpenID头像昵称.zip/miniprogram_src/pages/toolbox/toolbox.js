
Page({
  data:{
    // 呼吸
    breathing:false, phase:'', elapsed:0, breathModeIdx:0, breathAnim:{},
    modes:[ {name:'4‑4‑6', lens:[4,4,6], seq:['吸气','停顿','呼气']},
            {name:'4‑4‑4‑4（方块）', lens:[4,4,4,4], seq:['吸气','停顿','呼气','停顿']},
            {name:'4‑7‑8', lens:[4,7,8], seq:['吸气','停顿','呼气']} ],
    // 正念 1 分钟
    timing:false, left:60, mm:'01', ss:'00',
    // 蝴蝶拥抱
    tapping:false, side:'左', bpm:60,
    // 情绪温度计
    mood:5, moodLogging:false, moodHist:[]
  },

  // —— 呼吸练习节拍器 ——
  pickMode(e){ this.setData({breathModeIdx:Number(e.detail.value||0)}); },
  startBreath(){
    // 清理旧定时
    if(this._breathTimer) clearInterval(this._breathTimer);
    if(this._breathTick) clearInterval(this._breathTick);
    if(this._breathTimeout) clearTimeout(this._breathTimeout);

    const m = this.data.modes[this.data.breathModeIdx];
    const lens = m.lens.slice(); // 秒
    const seq = m.seq.slice();

    // 创建动画
    this._anim = wx.createAnimation({duration: 1000, timingFunction: 'ease-in-out'});
    // 重置到 1.0
    this._anim.scale(1).step({duration:0});
    this.setData({breathAnim: this._anim.export(), breathing:true, phase:seq[0], elapsed:0});

    let idx=0;
    const doPhase = () => {
      const phase = seq[idx];
      const durMs = Math.max(0, (lens[idx]||1) * 1000);
      // 根据阶段设定目标缩放
      if(phase.indexOf('吸')>=0){
        this._anim.scale(1.4).step({duration: durMs});
      } else if(phase.indexOf('呼')>=0){
        this._anim.scale(1.0).step({duration: durMs});
      } else { // 停顿，保持当前缩放
        const lastScale = (phase.indexOf('停')>=0) ? undefined : undefined;
        // 使用 0 时长维持当前值 + 一个同时长的空step
        this._anim.step({duration: durMs});
      }
      this.setData({ breathAnim: this._anim.export(), phase });

      // 倒计时节拍（秒）
      let remain = Math.round(durMs/1000);
      if(this._breathTick) clearInterval(this._breathTick);
      this._breathTick = setInterval(()=>{
        remain--; this.setData({elapsed:this.data.elapsed+1});
        if(remain<=0){ clearInterval(this._breathTick); }
      }, 1000);

      // 安排下一阶段
      this._breathTimeout = setTimeout(()=>{
        idx = (idx + 1) % seq.length;
        doPhase();
      }, durMs);
    };

    doPhase();
  },
  stopBreath(){
    if(this._breathTimer){ clearInterval(this._breathTimer); this._breathTimer=null; }
    if(this._breathTick){ clearInterval(this._breathTick); this._breathTick=null; }
    if(this._breathTimeout){ clearTimeout(this._breathTimeout); this._breathTimeout=null; }
    if(!this._anim) this._anim = wx.createAnimation({duration:0});
    this._anim.scale(1).step({duration:0});
    this.setData({breathAnim: this._anim.export(), breathing:false, phase:'', elapsed:0});
  },

  // —— 正念 1 分钟 ——
  startTimer(){
    if(this.data.timing) return; this.setData({timing:true});
    if(this._timer) clearInterval(this._timer);
    this._timer=setInterval(()=>{
      let left=this.data.left-1;
      if(left<=0){ left=0; this.stopTimer(); wx.showToast({title:'结束',icon:'none'}) }
      const mm=(''+Math.floor(left/60)).padStart(2,'0'); const ss=(''+(left%60)).padStart(2,'0');
      this.setData({left, mm, ss});
    },1000);
  },
  stopTimer(){ if(this._timer){ clearInterval(this._timer); this._timer=null; } this.setData({timing:false}); },
  resetTimer(){ this.setData({left:60, mm:'01', ss:'00', timing:false}); if(this._timer){ clearInterval(this._timer); this._timer=null; } },

  // —— 蝴蝶拥抱（双侧拍） ——
  startTapping(){
    if(this._tapTimer) clearInterval(this._tapTimer);
    // bpm 转换为间隔（一次左右切换为半拍，这里我们每次切换为一拍效果即可）
    let interval = Math.max(20, Math.round(60000/this.data.bpm));
    let leftSide = true;
    this.setData({tapping:true, side: leftSide ? '左' : '右'});
    this._tapTimer = setInterval(()=>{
      leftSide = !leftSide;
      this.setData({side: leftSide ? '左' : '右'});
      // 轻微震动提示（部分设备支持）
      if(wx.vibrateShort){ try{ wx.vibrateShort({type:'light'}) }catch(e){} }
    }, interval);
  },
  stopTapping(){ if(this._tapTimer){ clearInterval(this._tapTimer); this._tapTimer=null; } this.setData({tapping:false}); },
  changeBpm(e){ this.setData({bpm:Number(e.detail.value||60)}); if(this.data.tapping){ this.stopTapping(); this.startTapping(); } },

  // —— 情绪温度计（0–10） ——
  setMood(e){ this.setData({mood: Number(e.detail.value||0)}); },
  saveMood(){
    const item = { ts: Date.now(), date: new Date().toLocaleString(), mood: this.data.mood };
    const key='mood_log';
    const arr = (wx.getStorageSync(key) || []);
    arr.unshift(item);
    wx.setStorageSync(key, arr.slice(0, 30));
    this.setData({ moodHist: arr.slice(0,30) });
    wx.showToast({title:'已记录', icon:'none'});
  },
  loadMood(){
    const arr = wx.getStorageSync('mood_log') || [];
    this.setData({ moodHist: arr });
  },

  onShow(){ this.loadMood(); },
  onUnload(){ if(this._breathTimer) clearInterval(this._breathTimer); if(this._timer) clearInterval(this._timer); if(this._tapTimer) clearInterval(this._tapTimer); }
})
