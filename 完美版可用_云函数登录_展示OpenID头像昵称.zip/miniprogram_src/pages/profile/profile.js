const app=getApp()
Page({
  data:{c:{}, scoreText:''},
  date(ts){ const d=new Date(ts); return `${d.getFullYear()}-${d.getMonth()+1}-${d.getDate()}` },
  onShow(){
    const c = app.globalData.currentConsultant || (app.globalData.consultants && app.globalData.consultants[0]) || {}
    const scoreText = c.score ? (c.score>0 ? `❤️ +${c.score}` : `💔 ${c.score}`) : ''
    this.setData({c, scoreText})
  },
  goBooking(){ wx.navigateTo({url:'/pages/booking/booking'}) }
})
