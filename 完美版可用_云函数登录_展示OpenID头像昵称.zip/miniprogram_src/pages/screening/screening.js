
// === 自评量表（扩展版） ===

// —— 量表配置 ——
// 通用 0-3 频率选项
const OPTS_0_3 = [
  { label: '完全没有', value: 0 },
  { label: '几天', value: 1 },
  { label: '一半以上的天数', value: 2 },
  { label: '几乎每天', value: 3 }
];

// PHQ‑9（抑郁）
const PHQ9 = {
  name: 'PHQ‑9（抑郁自评）',
  desc: '过去两周内，每个问题的频率。',
  opts: OPTS_0_3,
  questions: [
    '对做事情提不起兴趣，或没有乐趣',
    '感到情绪低落、沮丧或绝望',
    '入睡困难、睡不安或睡得过多',
    '感到疲倦或缺乏精力',
    '食欲不振或吃得过多',
    '对自己很不满意，觉得自己很失败或让家人失望',
    '注意力不集中，如看报或看电视时',
    '动作或说话缓慢、或坐立不安、烦躁',
    '有伤害自己或不想活的念头（若有，请及时寻求专业帮助）'
  ],
  scoreLevel(score){
    if (score <= 4)  return ['最轻', '留意情绪变化，使用情绪工具箱尝试自助。'];
    if (score <= 9)  return ['轻度', '可结合呼吸、正念、规律作息；必要时考虑专业评估。'];
    if (score <= 14) return ['中度', '建议结合自助策略与线下专业评估。'];
    if (score <= 19) return ['中‑重度', '尽快联系专业人员进一步评估。'];
    return ['重度', '请尽快联系专业人员；如有危险念头，立刻寻求紧急帮助。'];
  }
};

// GAD‑7（焦虑）
const GAD7 = {
  name: 'GAD‑7（焦虑自评）',
  desc: '过去两周内，以下情况困扰你的频率。',
  opts: OPTS_0_3,
  questions: [
    '感到紧张、焦虑或烦躁',
    '无法停止或控制担忧',
    '对各种事情过度担心',
    '很难放松下来',
    '坐立不安，难以静坐',
    '容易烦躁或急躁',
    '担心会发生不好的事情'
  ],
  scoreLevel(score){
    if (score <= 4)  return ['最轻', '短期波动较常见，关注身心节律。'];
    if (score <= 9)  return ['轻度', '可尝试呼吸、正念、运动与睡眠卫生。'];
    if (score <= 14) return ['中度', '建议结合自助与专业评估。'];
    return ['重度', '请尽快联系专业人员评估与支持。'];
  }
};

// WHO‑5（身心幸福感）0–5 计分，乘 4 转为 0–100
const WHO5 = {
  name: 'WHO‑5（身心幸福感）',
  desc: '过去两周内，你的主观幸福感。结果会换算为 0–100。',
  opts: [
    { label: '从不 (0)', value: 0 },
    { label: '偶尔 (1)', value: 1 },
    { label: '少于一半时间 (2)', value: 2 },
    { label: '大部分时间 (3)', value: 3 },
    { label: '几乎一直 (4)', value: 4 }
  ],
  questions: [
    '我感到心情愉快、精神饱满',
    '我感到平静和放松',
    '我感到精力充沛、活力十足',
    '我每天醒来都精神良好',
    '我对日常生活中的事情感到兴趣'
  ],
  convert(score){ return score * 4; },
  scoreLevel(scoreRaw){
    // scoreRaw 为原始 0–20，先换算
    const score = scoreRaw * 4;
    if (score >= 70) return [`${score}`, '整体状态良好，保持良好习惯。'];
    if (score >= 52) return [`${score}`, '略低于最佳，维持与微调作息与社交。'];
    return [`${score}`, '可能存在困扰，建议进一步评估或寻求支持。'];
  }
};

// K10（心理困扰）0–4 计分，合计 0–40
const K10 = {
  name: 'K10（心理困扰）',
  desc: '过去四周内，你经历以下感受的频率。',
  opts: [
    { label: '从不 (0)', value: 0 },
    { label: '偶尔 (1)', value: 1 },
    { label: '有时 (2)', value: 2 },
    { label: '经常 (3)', value: 3 },
    { label: '总是 (4)', value: 4 }
  ],
  questions: [
    '感到疲惫不堪',
    '感到紧张',
    '因担忧而坐立不安',
    '感到绝望',
    '感觉一切都费力',
    '感到悲伤或沮丧',
    '难以安静下来',
    '感到一切都不好',
    '感到无助',
    '觉得毫无价值'
  ],
  scoreLevel(score){
    if (score <= 15) return ['较低', '总体困扰不高；留意自我照顾。'];
    if (score <= 21) return ['轻度', '建议结合自助策略调节与观察。'];
    if (score <= 29) return ['中度', '建议寻求专业意见。'];
    return ['重度', '建议尽快进行专业评估与支持。'];
  }
};

// ISI‑7（失眠严重度）0–4 计分
const ISI7 = {
  name: 'ISI‑7（失眠自评）',
  desc: '最近两周睡眠相关体验。',
  opts: [
    { label: '无 (0)', value: 0 },
    { label: '轻度 (1)', value: 1 },
    { label: '中度 (2)', value: 2 },
    { label: '重度 (3)', value: 3 },
    { label: '极重 (4)', value: 4 }
  ],
  questions: [
    '入睡困难程度',
    '夜间觉醒次数/维持睡眠困难程度',
    '过早醒来程度',
    '对当前睡眠满意度',
    '睡眠问题对日间功能影响',
    '他人对你睡眠问题的担忧程度',
    '睡眠问题造成的困扰程度'
  ],
  scoreLevel(score){
    if (score <= 7)  return ['无/最轻', '维持基本睡眠卫生。'];
    if (score <= 14) return ['轻度', '调整作息、限制咖啡因、睡前放松。'];
    if (score <= 21) return ['中度', '建议优化睡眠习惯并考虑专业评估。'];
    return ['重度', '建议尽快寻求专业睡眠评估（如 CBT‑I）。'];
  }
};

const SCALES = [PHQ9, GAD7, WHO5, K10, ISI7];

Page({
  data: {
    scales: SCALES.map(s=>s.name),
    idx: 0,
    desc: SCALES[0].desc,
    questions: SCALES[0].questions.map(q => ({ q })),
    opts: SCALES[0].opts,
    answers: Array(SCALES[0].questions.length).fill(null),
    score: null,
    level: '',
    advice: '',
    history: []
  },

  pickScale(e){
    const idx = Number(e.detail.value || 0);
    const conf = SCALES[idx];
    this.setData({
      idx,
      desc: conf.desc,
      questions: conf.questions.map(q => ({ q })),
      opts: conf.opts,
      answers: Array(conf.questions.length).fill(null),
      score: null, level: '', advice: ''
    });
  },

  pickOpt(e){
    const i = Number(e.currentTarget.dataset.i);
    const v = Number(e.detail.value);
    const arr = this.data.answers.slice();
    arr[i] = v;
    this.setData({ answers: arr });
  },

  calc(){
    const conf = SCALES[this.data.idx];
    if (this.data.answers.some(v => v === null)){
      wx.showToast({ title: '还有题目未作答', icon: 'none' });
      return;
    }
    let raw = this.data.answers.reduce((a,b)=>a+b,0);
    let scoreText = String(raw);
    let level, advice;
    if (typeof conf.convert === 'function'){
      // e.g. WHO‑5 转换成 0–100
      const [lvl, adv] = conf.scoreLevel(raw);
      level = '分值';
      advice = adv;
      scoreText = lvl; // conf.scoreLevel 已将分值转为文本
    } else {
      const [lvl, adv] = conf.scoreLevel(raw);
      level = lvl; advice = adv;
    }
    this.setData({ score: scoreText, level, advice });
  },

  save(){
    if (this.data.score === null){
      wx.showToast({ title: '请先计算分数', icon: 'none' });
      return;
    }
    const conf = SCALES[this.data.idx];
    const item = {
      ts: Date.now(),
      date: new Date().toLocaleString(),
      name: conf.name,
      score: this.data.score,
      level: this.data.level,
      advice: this.data.advice
    };
    const key = 'screening_history';
    let arr = wx.getStorageSync(key) || [];
    arr.unshift(item);
    wx.setStorageSync(key, arr.slice(0, 10));
    this.setData({ history: arr.slice(0, 10) });
    wx.showToast({ title: '已保存', icon: 'none' });
  },

  loadHistory(){
    const key = 'screening_history';
    const arr = wx.getStorageSync(key) || [];
    this.setData({ history: arr });
  },

  clearHistory(){
    wx.showModal({
      title: '确认删除',
      content: '确定清空全部历史记录吗？此操作不可恢复。',
      confirmText:'清空',
      confirmColor:'#d00',
      success: (res)=>{
        if (res.confirm){
          const key='screening_history';
          try{ wx.removeStorageSync(key) }catch(e){}
          this.setData({ history: [] });
          wx.showToast({title:'已清空历史', icon:'none'});
        }
      }
    })
  },

  onShow(){ this.loadHistory(); }
});
