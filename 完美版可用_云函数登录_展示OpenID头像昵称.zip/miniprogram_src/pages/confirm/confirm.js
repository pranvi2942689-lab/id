const app=getApp()
Page({
  data:{c:{}, datetime:'—', payMode:'postpay', amount:'0', method:'', submitting:false},
  onShow(){
    const c = app.globalData.currentConsultant
    const b = app.globalData.booking
    const datetime = `${app.humanDate(b.date)} ${b.slot}（${b.method==='offline'?'线下咨询':'线上咨询'}）`
    const payMode = b.method==='online' ? 'prepay' : app.globalData.payMode
    const base = c.price
    const disc = (payMode==='prepay' && app.globalData.reOrderDiscount) ? app.globalData.reOrderDiscount : 1
    const amount = app.money(base*disc)
    this.setData({c, datetime, payMode, amount, method:b.method, submitting:false})
  },
  pickPay(e){
    if(this.data.method==='online' && e.currentTarget.dataset.m==='postpay'){ wx.showToast({title:'线上咨询需先付费', icon:'none'}); return; }
    const payMode = e.currentTarget.dataset.m
    const c = app.globalData.currentConsultant
    const base = c.price
    const disc = (payMode==='prepay' && app.globalData.reOrderDiscount) ? app.globalData.reOrderDiscount : 1
    this.setData({payMode, amount:app.money(base*disc)})
  },
  action(){ if(this.data.submitting) return; this.setData({submitting:true});
    if(this.data.payMode==='prepay'){
      app.globalData.payPurpose='reservation'
      wx.navigateTo({url:'/pages/pay/pay?amt='+this.data.amount})
    }else{
      this.createOrder(false)
      wx.showModal({title:'预约成功', content:'工作人员马上电话联系您。', showCancel:false, success:()=>{
        wx.switchTab({url:'/pages/orders/orders'})
      }})
    }
  },
  createOrder(paid){
    const c = app.globalData.currentConsultant
    const b = app.globalData.booking
    app.globalData.orders.push({
      id: (Date.now()*1000 + Math.floor(Math.random()*1000)),
      consultant: c,
      price: c.price,
      date: b.date,
      slot: b.slot,
      method: b.method,
      paid: !!paid,
      commented: false,
      rated: 0,
      tipped: false,
      tipAmount: 0,
      messages: [],
      awaitingReply: false
    })
  }
})
