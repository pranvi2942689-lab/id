if (!wx.cloud) { console.warn('基础库过低，云能力不可用'); } else { wx.cloud.init({ traceUser: true }); }
App({
  onLaunch(){
    try{
      const opts = wx.getLaunchOptionsSync ? wx.getLaunchOptionsSync() : {};
      const launchPath = opts && opts.path ? ('/' + opts.path) : '';
      const tabSet = new Set(['/pages/home/home','/pages/list/list','/pages/orders/orders','/pages/consumption/consumption']);
      // 如果启动路径不是任一 tabBar 页面，强制回到首页，避免落入已删除的旧路由导致白屏
      if(!launchPath || !tabSet.has(launchPath)){
        wx.switchTab({url:'/pages/home/home'});
      }
    }catch(e){ /* ignore */ }
  },

  globalData:{
    consultants:[
      { id:1, name:"唐海波", avatar:"/assets/tang.jpg", gender:"male", price:3000, title:"中南大学心理健康教育与咨询专家、教授、临床心理学博士", time:"需提前一天预约", tags:["危机干预"], long:"【基本情况】教授，临床心理学博士。\n【擅长】危机干预、急性应激、哀伤辅导。\n【提示】高峰期需提前一天预约。", score:0, reviews:[] },
      { id:2, name:"邹美红", avatar:"/assets/zou.jpg", gender:"female", price:2000, title:"国家二级心理咨询师、资深法律工作者", time:"周一到周日 9:00～20:00", tags:["夫妻关系","亲子关系"], long:"【基本情况】国家二级心理咨询师。\n【擅长】婚姻家庭、亲子沟通、家庭系统。\n【风格】温和而有力量，重视来访者的资源。", score:0, reviews:[] },
      { id:3, name:"罗飞", avatar:"/assets/luo.jpg", gender:"female", price:1200, title:"湖南省高校心理协会 / 心理咨询师", time:"周一到周日 9:00～20:00", tags:["个人成长","亲子关系","职业规划","青少年心理"],
        long:"罗飞，国家二级心理咨询师、国家一级人力资源师，拥有企业与高校双背景：曾任高校心健中心负责人、集团HR/运营总监15年，系统受训于CBT（中德班/北大回龙观）、NLP、艾瑞克森催眠与心理测量。\n累计个案千余小时、督导近2000小时，主讲百余场讲座并长期参与公益；与政府有合作，为华润集团提供企业EAP方案并负责落地执行。\n擅长个人成长、亲子/亲密关系、职业规划与人岗匹配，风格沉稳高效、洞察力强，直指关键并给出可执行的改变路径，效果可感可见。",
        score:0, reviews:[] }
    ],
    tagsPool:["危机干预","夫妻关系","亲子关系","个人成长","职业规划","青少年心理"],
    booking:{method:null,date:null,slot:null,name:"",phone:""},
    payMode:"postpay",
    reOrderDiscount:null,
    currentConsultant:null,
    orders:[],
    supportMsgs:[],
    freeTalks:{},
    payPurpose:"reservation",
    tipTemp:0,
    tipOrderId:null,
    lotteryDrawn:false
  },
  toast(msg){ wx.showToast({title: msg, icon:'none'}) },
  money(n){return (Math.round(n*100)/100).toFixed(n%1===0?0:2)},
  humanMD(iso){ if(!iso) return '—'; const d=new Date(iso+'T00:00:00'); return `${d.getMonth()+1}月${d.getDate()}号`; },
  humanDate(iso){ if(!iso) return "—"; const d = new Date(iso+"T00:00:00"); return `${d.getFullYear()}-${d.getMonth()+1}-${d.getDate()}`; },
  pad(n){return (''+n).padStart(2,'0');},
  toLocalISO(d){return `${d.getFullYear()}-${('0'+(d.getMonth()+1)).slice(-2)}-${('0'+d.getDate()).slice(-2)}`;}
  ,
  safeNavigateBack(delta=1, fallback='/pages/home/home'){
    try{
      const pages = getCurrentPages();
      if(pages && pages.length > delta){
        wx.navigateBack({ delta });
        return;
      }
    }catch(e){}
    wx.switchTab({ url: fallback, fail: () => wx.reLaunch({ url: fallback }) });
  }
})