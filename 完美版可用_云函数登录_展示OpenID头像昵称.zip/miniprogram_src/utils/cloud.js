const ENV = 'cloud1-6g9pnabu70de5130';
function call(name, data = {}, config = {}, opts = {"showLoading": false}) {
  const final = { name, data, config: { env: ENV, ...(config||{}) } };
  if (opts.showLoading) wx.showLoading({ title: '加载中' });
  return wx.cloud.callFunction(final).finally(() => opts.showLoading && wx.hideLoading());
}
module.exports = { call, ENV };